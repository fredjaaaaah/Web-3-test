﻿using StripsBL.DTOs;
using StripsBL.Exceptions;
using StripsBL.Model;
using StripsREST.Model.Output;

namespace StripsREST.Mappers
{
    public class MapToDomain
    {


        public static List<Auteur> MapToAuteur(StripDTO stripDTO)
        {
            List<Auteur> auteurs = new List<Auteur>();

            try
            {
                foreach (string s in stripDTO.Auteurs)
                {
                    auteurs.Add(new Auteur(s));
                }
            }
            catch (Exception ex)
            {

                throw new MapException("MapToAuteur", ex);
            }
            return auteurs;
        }

        public static Reeks MapToReeks(StripDTO stripDTO)
        {
            try
            {
                return new Reeks(stripDTO.Reeks);
            }
            catch (Exception ex)
            {

                throw new MapException("MapToReeks", ex);
            }
        }
        public static Uitgeverij MapToUitgeverij(StripDTO stripDTO)
        {
            try
            {
                return new Uitgeverij(stripDTO.Uitgeverij);
            }
            catch (Exception ex)
            {

                throw new MapException("MapToUitgeverij", ex);
            }
        }


        public static StripOutputDTO Map(StripDTO stripDTO)
        {
            try
            {
                return new StripOutputDTO
                {
                    Url = stripDTO.Url,
                    Titel = stripDTO.Titel,
                    Nr = stripDTO.Nr,
                    Reeks = stripDTO.Reeks,
                    ReeksUrl = stripDTO.ReeksUrl,
                    Uitgeverij = stripDTO.Uitgeverij,
                    UitgeverijUrl = stripDTO.ReeksUrl,
                    Auteurs = stripDTO.Auteurs

                };
            }
            catch (Exception ex)
            {

                throw new MapException("MaptpStripOutputDTO", ex);
            }

        }

    }
}
