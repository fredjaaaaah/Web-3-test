﻿using StripsBL.Model;

namespace StripsREST.Model.Output
{
    public class StripOutputDTO
    {
        public StripOutputDTO()
        {
        }

        public StripOutputDTO(int url, string titel, int? nr, string reeks, int reeksUrl, string uitgeverij, int uitgeverijUrl, List<string> auteurs)
        {
            Url = url;
            Titel = titel;
            Nr = nr;
            Reeks = reeks;
            ReeksUrl = reeksUrl;
            Uitgeverij = uitgeverij;
            UitgeverijUrl = uitgeverijUrl;
            Auteurs = auteurs;
        }

        public int Url { get; set; }
        public string Titel { get; set; }
        public int? Nr { get; set; }
        public string Reeks { get; set; }
        public int ReeksUrl { get; set; }
        public string Uitgeverij { get; set; }
        public int UitgeverijUrl { get; set; }
        public List<string> Auteurs { get; set; }
    }
}
