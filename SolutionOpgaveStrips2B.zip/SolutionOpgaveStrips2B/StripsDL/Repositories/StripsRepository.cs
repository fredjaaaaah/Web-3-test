﻿//using StripsBL.DTOs;
using StripsBL.DTOs;
using StripsBL.Exceptions;
using StripsBL.Interfaces;
using StripsBL.Model;
using StripsDL.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace StripsDL.Repositories
{
    public class StripsRepository : IStripsRepository
    {
        private string connectionString;
        
        public StripsRepository(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public StripDTO GeefStrip(int stripID)
        {
            string sql = "SELECT s.Id AS Url, s.Nr, s.Titel, r.Naam AS Reeks, r.Id AS ReeksUrl, u.Naam AS Uitgeverij, u.Id AS UitgeverijUrl, a.Naam AS Auteur " +
                "FROM Strip s LEFT JOIN Reeks r ON s.Reeks = r.Id "+
                "LEFT JOIN Uitgeverij u ON s.Uitgeverij = u.id " +
                "LEFT JOIN StripAuteur sa ON s.Id = sa.StripId " +
                " LEFT JOIN Auteur a ON sa.AuteurId = a.Id " +
                " WHERE s.Id = @stripID";
            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                try
                {
                    conn.Open();
                    cmd.CommandText = sql;
                    cmd.Parameters.AddWithValue("@StripID", stripID);
                    IDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    var v = dr.GetOrdinal("Reeks");
                    var x = dr.GetString(dr.GetOrdinal("Reeks"));
                    StripDTO s = new StripDTO{
                        
                        Url = dr.GetInt32(dr.GetOrdinal("Url")),
                        Nr = dr.IsDBNull(dr.GetOrdinal("Nr")) ? (int?)null : dr.GetInt32(dr.GetOrdinal("Nr")),
                        Titel = dr.GetString(dr.GetOrdinal("Titel")),
                        Reeks = dr.GetString(dr.GetOrdinal("Reeks")),
                        ReeksUrl = dr.GetInt32(dr.GetOrdinal("ReeksUrl")),
                        Uitgeverij = dr.GetString(dr.GetOrdinal("Uitgeverij")),
                        UitgeverijUrl = dr.GetInt32(dr.GetOrdinal("UitgeverijUrl")),
                        Auteurs = new List<string> { dr.GetString(dr.GetOrdinal("Auteur")) }               
                        
                       /* Url = dr.IsDBNull(dr.GetOrdinal("Url")) ? 0 : dr.GetInt32(dr.GetOrdinal("Url")),
                        Nr = dr.IsDBNull(dr.GetOrdinal("Nr")) ? (int?)null : dr.GetInt32(dr.GetOrdinal("Nr")),
                        Titel = dr.GetString(dr.GetOrdinal("Titel")),
                        Reeks = dr.GetString(dr.GetOrdinal("Reeks")),
                        ReeksUrl = dr.IsDBNull(dr.GetOrdinal("ReeksUrl")) ? 0 : dr.GetInt32(dr.GetOrdinal("ReeksUrl")),
                        Uitgeverij = dr.GetString(dr.GetOrdinal("Uitgeverij")),
                        UitgeverijUrl = dr.IsDBNull(dr.GetOrdinal("UitgeverijUrl")) ? 0 : dr.GetInt32(dr.GetOrdinal("UitgeverijUrl")),
                        Auteurs = new List<string> { dr.GetString(dr.GetOrdinal("Auteur")) }*/
                    };
                    dr.Close();
                    return s;
                }
                catch (Exception ex)
                {
                    throw new StripsRepositoryException("GeefStrip niet gelukt", ex);
                }
                finally
                {
                    conn.Close();
                }
            }
        }
    }
}
