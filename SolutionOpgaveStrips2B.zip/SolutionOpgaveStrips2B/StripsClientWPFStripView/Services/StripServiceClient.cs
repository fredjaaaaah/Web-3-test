﻿using StripsBL.DTOs;
using StripsBL.Exceptions;
using StripsBL.Interfaces;
using StripsClientWPFStripView.Exceptions;
using StripsDL.Repositories;
//using StripsClientWPFStripView.Model;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace StripsClientWPFStripView.Services
{
    public class StripServiceClient
    {
        private HttpClient client;

        private IStripsRepository _repo;



        public StripServiceClient(IStripsRepository repo)
        {
            _repo = repo;

        }


        public StripDTO GeefStrip(int id)
        {
            try
            {
                return _repo.GeefStrip(id);
            }
            catch (Exception ex)
            {

                throw new StripsManagerException("GeefStrip", ex);
            }
        }
    }
}
