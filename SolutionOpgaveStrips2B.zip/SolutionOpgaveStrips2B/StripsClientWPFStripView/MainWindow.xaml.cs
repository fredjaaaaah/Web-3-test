﻿//using StripsClientWPFStripView.Model;
using StripsBL.DTOs;
using StripsClientWPFStripView.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StripsClientWPFStripView
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private StripServiceClient stripService;
        private string path;
        public MainWindow()
        {
            InitializeComponent();
            //stripService = new StripServiceClient();
        }

        private async void GetStripButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id;
                if (int.TryParse(StripIdTextBox.Text, out id))
                {
                    FillRest(stripService.GeefStrip(id));
                }
                else
                {
                    MessageBox.Show("Invalid ID");
                }
                
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        public void FillRest(StripDTO stripDTO)
        {
            TitelTextBox.Text = stripDTO.Titel;
            NrTextBox.Text = stripDTO.Nr.ToString();
            ReeksTextBox.Text = stripDTO.Reeks.ToString();
            UitgeverijTextBox.Text = stripDTO.Reeks.ToString();
            //List<string> auteurs = stripDTO.Auteurs;
        }
    }
}
